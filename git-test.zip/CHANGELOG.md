# Changelog

## [1.5.3] - 2026-01-20 - GitHub Ready Release 🚀

### Added
- **LICENSE**: MIT License for open source distribution
- **.env.example**: Environment variables template
- **GITHUB_CHECKLIST.md**: Complete pre-release checklist
- **test-api.ps1**: UTF-8 encoding fix for proper emoji display
- **test-api.ps1**: Added 1.2s delay before PATCH to ensure updated_at changes

### Updated
- **.gitignore**: Added `.env` to exclusions
- **README.md**: Added LICENSE section and .env.example to project structure
- **README.md**: Enhanced environment variables documentation

### Documentation
All files ready for GitHub:
- ✅ README.md - Complete API documentation
- ✅ CHANGELOG.md - Version history
- ✅ PORTFOLIO.md - Portfolio showcase
- ✅ PRODUCTION_READY.md - Quality checklist
- ✅ GITHUB_CHECKLIST.md - Release checklist
- ✅ LICENSE - MIT License
- ✅ .env.example - Configuration template
- ✅ .gitignore - Proper exclusions

## [1.5.2] - 2026-01-20

### Added
- **test-api.ps1**: Comprehensive automated test suite
  - Tests all 11 endpoints
  - Validates HTTP status codes (200, 201, 204, 400, 404, 422)
  - Tests CRUD operations with proper ID tracking
  - Tests null value handling
  - Tests validation errors
  - Color-coded output for easy reading

### Updated
- **README.md**: Added automated testing section
- **README.md**: Clarified requirements (no additional extensions needed)

### Testing Results
All 11 tests pass successfully:
```
✅ Test 1: Create task with timestamps (201)
✅ Test 2: PATCH - Update status (200)
✅ Test 3: PATCH - Clear description with null (200)
✅ Test 4: PUT - Full update (200)
✅ Test 5: GET single task (200)
✅ Test 6: GET list with filters (200)
✅ Test 7: Invalid JSON (400)
✅ Test 8: Validation error (422)
✅ Test 9: Query validation (422)
✅ Test 10: DELETE task (204)
✅ Test 11: GET deleted task (404)
```

## [1.5.1] - 2026-01-20

### Fixed
- **mb_strlen() dependency**: Changed to `strlen()` to avoid mbstring extension requirement
- **Compatibility**: Now works with default PHP installation

## [1.5.0] - 2026-01-20

### Fixed - Critical Production Issues

#### TaskRepository.php
- **Timestamps in create()**: Now explicitly inserts `created_at` and `updated_at` with `datetime('now')`
- **Reliability**: Works regardless of database DEFAULT settings
- **Consistency**: All operations (create, patch, put) now handle timestamps explicitly

#### migrations/001_create_tasks.sql
- **CHECK constraint**: Added `CHECK (status IN ('pending', 'in_progress', 'done'))` for database-level validation
- **Data integrity**: Invalid status values rejected at database level, not just application level

#### All PHP files
- **Type safety**: Added `declare(strict_types=1);` to all files for maximum type safety
- **Professional standard**: Follows PHP best practices throughout

### Code Quality Improvements

#### Type Declarations Added
- ✅ `src/Database.php`
- ✅ `src/Request.php`
- ✅ `src/Response.php`
- ✅ `src/Router.php`
- ✅ `src/TaskController.php`
- ✅ `src/TaskRepository.php`
- ✅ `src/TaskStatus.php`
- ✅ `src/Validator.php` (already had it)

#### Database Constraints
```sql
-- Before
status TEXT NOT NULL DEFAULT 'pending'

-- After
status TEXT NOT NULL DEFAULT 'pending' 
  CHECK (status IN ('pending', 'in_progress', 'done'))
```

This ensures data integrity even if application validation is bypassed.

#### Timestamp Handling
```php
// Before (relied on database DEFAULT)
INSERT INTO tasks (title, description, status) VALUES (...)

// After (explicit and reliable)
INSERT INTO tasks (title, description, status, created_at, updated_at) 
VALUES (:title, :description, :status, datetime('now'), datetime('now'))
```

### Testing Results
All production scenarios verified:
```bash
✅ CREATE with timestamps → Both created_at and updated_at set
✅ PATCH updates → updated_at refreshed, created_at unchanged
✅ PUT updates → updated_at refreshed, created_at unchanged
✅ Invalid status → Rejected at database level
✅ Query validation → Returns 422
✅ All type declarations → Strict mode active
```

### Production Readiness Checklist
- ✅ Type safety (`declare(strict_types=1)` everywhere)
- ✅ Database constraints (CHECK for status)
- ✅ Explicit timestamp handling
- ✅ Proper HTTP status codes (400 vs 422)
- ✅ Null value support
- ✅ SQL injection protection
- ✅ Error logging without exposure
- ✅ Comprehensive validation
- ✅ Edge cases handled
- ✅ Documentation complete

## [1.4.0] - 2026-01-20

### Fixed - Final Polish
- 204 header handling (headers sent, body omitted)
- Validator perfect with `array_key_exists()`
- All validation errors return 422
- Malformed JSON returns 400

## [1.3.0] - 2026-01-20

### Fixed - Critical Bug Fixes
- Invalid JSON detection
- HTTP status codes consistency
- All improvements verified

## [1.2.0] - 2026-01-20

### Fixed - Production-Ready Improvements
- Content-Type with charset
- Response envelope consistency
- Repository reliability
- Validator rewrite with null support

## [1.1.0] - 2026-01-20

### Fixed - Initial Production Fixes
- Content-Type header parsing
- Path normalization
- Invalid JSON handling
- Exception handling (Throwable)
- Security improvements
